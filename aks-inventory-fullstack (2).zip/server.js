// AKS Diagnostic Center — Inventory backend.
// Express + SQLite. Serves the static app from /public and a small REST API
// that the frontend's window.storage shim talks to. There are no accounts —
// anyone with the URL can open the app and read/write the shared inventory.

const path = require('path');
const fs = require('fs');
const express = require('express');
const cors = require('cors');
const Database = require('better-sqlite3');

// Load .env if present (simple built-in loader — keeps dependencies minimal).
(function loadDotEnv(){
  const envPath = path.join(__dirname, '.env');
  if (!fs.existsSync(envPath)) return;
  fs.readFileSync(envPath, 'utf8').split('\n').forEach(line => {
    const m = line.match(/^\s*([\w.-]+)\s*=\s*(.*)?\s*$/);
    if (m && !process.env[m[1]]) process.env[m[1]] = (m[2] || '').trim();
  });
})();

const PORT = process.env.PORT || 3000;
const DATA_DIR = process.env.DATA_DIR || path.join(__dirname, 'data');

if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR, { recursive: true });
const db = new Database(path.join(DATA_DIR, 'aks.db'));
db.pragma('journal_mode = WAL');

db.exec(`
  CREATE TABLE IF NOT EXISTS storage (
    key TEXT NOT NULL,
    shared INTEGER NOT NULL,
    value TEXT NOT NULL,
    saved_at TEXT NOT NULL DEFAULT (datetime('now')),
    PRIMARY KEY (key, shared)
  );
`);

const app = express();
app.use(cors());
app.use(express.json({ limit: '10mb' }));

// ---------- STORAGE (matches the window.storage shape the frontend expects) ----------
// "shared" is kept for API compatibility with the frontend, but in this backend
// all data is lab-wide (everyone who opens the app sees the same inventory).
app.get('/api/storage', (req, res) => {
  const shared = req.query.shared === 'true' || req.query.shared === '1' ? 1 : 0;
  const prefix = req.query.prefix || '';
  const rows = db.prepare('SELECT key FROM storage WHERE shared = ? AND key LIKE ?').all(shared, prefix + '%');
  res.json({ keys: rows.map(r => r.key), prefix, shared: !!shared });
});

app.get('/api/storage/:key', (req, res) => {
  const shared = req.query.shared === 'true' || req.query.shared === '1' ? 1 : 0;
  const row = db.prepare('SELECT value FROM storage WHERE key = ? AND shared = ?').get(req.params.key, shared);
  if (!row) return res.status(404).json({ error: 'Key not found: ' + req.params.key });
  res.json({ key: req.params.key, value: row.value, shared: !!shared });
});

app.put('/api/storage/:key', (req, res) => {
  const { value, shared } = req.body || {};
  const sharedFlag = shared ? 1 : 0;
  if (typeof value !== 'string') return res.status(400).json({ error: 'value must be a string.' });
  db.prepare(`
    INSERT INTO storage (key, shared, value, saved_at) VALUES (?, ?, ?, datetime('now'))
    ON CONFLICT(key, shared) DO UPDATE SET value = excluded.value, saved_at = excluded.saved_at
  `).run(req.params.key, sharedFlag, value);
  res.json({ key: req.params.key, value, shared: !!sharedFlag });
});

app.delete('/api/storage/:key', (req, res) => {
  const shared = req.query.shared === 'true' || req.query.shared === '1' ? 1 : 0;
  db.prepare('DELETE FROM storage WHERE key = ? AND shared = ?').run(req.params.key, shared);
  res.json({ key: req.params.key, deleted: true, shared: !!shared });
});

// ---------- STATIC APP ----------
app.use(express.static(path.join(__dirname, 'public')));
app.get('*', (req, res) => {
  if (req.path.startsWith('/api/')) return res.status(404).json({ error: 'Not found' });
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

app.listen(PORT, () => {
  console.log(`AKS Inventory backend running on http://localhost:${PORT}`);
});
