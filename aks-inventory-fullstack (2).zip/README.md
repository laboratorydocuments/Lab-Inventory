# AKS Diagnostic Center — Inventory (full app, with backend)

A real client-server version of the inventory app: a Node.js/Express + SQLite
backend, and the same frontend you've been using, now with data that lives on
the server — so everyone on the team sees the same inventory, from any
device, automatically synced. No more per-browser data.

There's no login — anyone who opens the app's URL can view and edit the
shared inventory directly.

## What's in here
- `server.js` — the backend: a small storage API the frontend talks to.
- `public/` — the frontend app (`index.html`, `manifest.json`, `sw.js`, `icons/`),
  served by the same server.
- `data/` — created automatically; holds `aks.db`, the SQLite database with
  all inventory data. **Back this folder up.**

## How access works
- There are no accounts and no sign-in screen. Opening the app's URL opens the
  live, shared inventory straight away.
- Everyone who opens it sees and edits the same data — this isn't per-user
  private data, it's your lab's shared records.
- Because there's no login, treat the URL itself as the access control: only
  share it with people who should be able to view and edit the inventory
  (e.g. keep it off the public internet, or put it behind your own network/VPN
  if that matters for your setup).

## Run it locally
Requires [Node.js](https://nodejs.org) 18 or newer.

```bash
npm install
npm start
```
Open **http://localhost:3000** — you're straight into the app.
Daily/Monthly/Yearly/Stock/Items/Machines all work the same way as before,
just saving to the server instead of the browser.

## Deploying so your whole team can use it
You need to host this Node app somewhere reachable by everyone's phone/computer.
Two easy, low/no-cost options:

### Option A — Render.com (recommended, free tier available)
1. Push this folder to a GitHub repo.
2. On [render.com](https://render.com), click **New → Web Service**, connect the repo.
3. Build command: `npm install`   Start command: `npm start`
4. **Important:** Render's free tier has an ephemeral filesystem — the `data/`
   folder (your database) can be wiped on redeploy. Add a **Persistent Disk**
   (Render's paid disks, a few dollars/month) mounted at `/opt/render/project/src/data`,
   or use their free Postgres add-on instead of SQLite for real production use —
   ask me and I can convert the backend to Postgres if you want that.
5. Deploy. Render gives you a URL like `https://aks-inventory.onrender.com` —
   that's what your staff opens (on phone or desktop, "Add to Home Screen" for
   an app-like icon). Remember: anyone with this URL can view/edit the
   inventory, so keep it out of search engines and only share it with staff.

### Option B — Your own VPS (DigitalOcean, a spare Linux server, etc.)
1. Copy this whole folder to the server.
2. `npm install --production`
3. Run it persistently with [pm2](https://pm2.keymetrics.io/):
   ```bash
   npm install -g pm2
   pm2 start server.js --name aks-inventory
   pm2 save
   pm2 startup
   ```
4. Put Nginx (or Caddy) in front for HTTPS — a free
   [Let's Encrypt](https://letsencrypt.org) certificate via `certbot` is enough.
   This is also a natural place to add HTTP Basic Auth or an IP allowlist if
   you want a lightweight access gate without a full login system.
5. Your staff opens `https://your-domain.com`.

## Backups
The whole database is one file: `data/aks.db`. Back it up regularly —
copy it off the server on a schedule (cron + `scp`/cloud storage, or your
host's snapshot feature). The in-app "⬇ Backup Data" button still works too,
and downloads everything as a portable JSON file from inside the app.

## Google Drive auto-backup
Still works exactly as before (see the "☁ Google Drive Backup" button in the
header) — once you set the Authorized JavaScript origin in Google Cloud
Console to your real hosted URL (e.g. `https://aks-inventory.onrender.com`).

## Security notes
- There's no login, so anything reachable at the app's URL is fully readable
  and writable by whoever has that URL — there's no per-user access control
  or activity log of who changed what.
- If that's a concern, the simplest options are: keep the URL private/unlisted,
  put it on a private network or VPN, or add HTTP Basic Auth / an IP allowlist
  at the Nginx/Caddy layer (Option B above). Let me know if you'd like a
  lightweight login system added back in.
- Always run behind HTTPS in production (Render gives you this automatically;
  on your own VPS, set it up via Nginx/Caddy + Let's Encrypt).
